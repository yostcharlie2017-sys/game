# Dungeon Escape - A Hard Python Terminal Game
# Save as: dungeon_escape.py
# Run with: python dungeon_escape.py

import random
import time
import os

WIDTH = 10
HEIGHT = 10

player_hp = 100
gold = 0
potions = 2

player_x = 0
player_y = 0

exit_x = WIDTH - 1
exit_y = HEIGHT - 1

enemies = []
treasures = []
traps = []

# Generate enemies
for _ in range(12):
    enemies.append([
        random.randint(0, WIDTH - 1),
        random.randint(0, HEIGHT - 1),
        random.randint(20, 50)
    ])

# Generate treasure
for _ in range(8):
    treasures.append([
        random.randint(0, WIDTH - 1),
        random.randint(0, HEIGHT - 1)
    ])

# Generate traps
for _ in range(10):
    traps.append([
        random.randint(0, WIDTH - 1),
        random.randint(0, HEIGHT - 1)
    ])


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def draw_map():
    for y in range(HEIGHT):
        for x in range(WIDTH):

            if x == player_x and y == player_y:
                print("P", end=" ")

            elif x == exit_x and y == exit_y:
                print("E", end=" ")

            else:
                print(".", end=" ")
        print()


def fight(enemy):
    global player_hp, gold

    enemy_hp = enemy[2]

    print("\n⚔ A monster attacks!")

    while enemy_hp > 0 and player_hp > 0:

        print(f"\nYour HP: {player_hp}")
        print(f"Monster HP: {enemy_hp}")

        action = input("Attack or Run? ").lower()

        if action == "attack":

            damage = random.randint(10, 25)
            enemy_hp -= damage
            print(f"You hit for {damage} damage!")

            if enemy_hp > 0:
                enemy_damage = random.randint(5, 20)
                player_hp -= enemy_damage
                print(f"The monster hits you for {enemy_damage}!")

        elif action == "run":

            if random.random() < 0.5:
                print("You escaped!")
                return
            else:
                print("You failed to escape!")

                enemy_damage = random.randint(5, 15)
                player_hp -= enemy_damage
                print(f"The monster hits you for {enemy_damage}!")

    if player_hp > 0:
        reward = random.randint(15, 50)
        gold += reward
        print(f"\nYou defeated the monster!")
        print(f"You found {reward} gold!")

        enemies.remove(enemy)

    else:
        print("\nYou died...")


def check_tile():
    global gold, player_hp, potions

    # Enemy check
    for enemy in enemies:
        if enemy[0] == player_x and enemy[1] == player_y:
            fight(enemy)
            return

    # Treasure check
    for treasure in treasures:
        if treasure[0] == player_x and treasure[1] == player_y:
            found = random.randint(10, 40)
            gold += found
            print(f"\n💰 You found {found} gold!")
            treasures.remove(treasure)

    # Trap check
    for trap in traps:
        if trap[0] == player_x and trap[1] == player_y:
            damage = random.randint(10, 30)
            player_hp -= damage
            print(f"\n☠ Trap! You lost {damage} HP!")
            traps.remove(trap)

            if random.random() < 0.3:
                potions += 1
                print("You found a potion nearby!")


while True:

    clear()

    print("=== DUNGEON ESCAPE ===")
    print(f"HP: {player_hp}")
    print(f"Gold: {gold}")
    print(f"Potions: {potions}")
    print()

    draw_map()

    if player_hp <= 0:
        print("\nGAME OVER")
        break

    if player_x == exit_x and player_y == exit_y:
        print("\n🎉 YOU ESCAPED THE DUNGEON!")
        print(f"Final Gold: {gold}")
        break

    print("\nMove: W A S D")
    print("Type P to use potion (+30 HP)")
    move = input("> ").lower()

    if move == "w" and player_y > 0:
        player_y -= 1

    elif move == "s" and player_y < HEIGHT - 1:
        player_y += 1

    elif move == "a" and player_x > 0:
        player_x -= 1

    elif move == "d" and player_x < WIDTH - 1:
        player_x += 1

    elif move == "p":

        if potions > 0:
            potions -= 1
            player_hp += 30

            if player_hp > 100:
                player_hp = 100

            print("\n🧪 You used a potion!")

            time.sleep(1)

        else:
            print("\nNo potions left!")
            time.sleep(1)

    check_tile()